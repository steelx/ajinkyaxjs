Ajinkya Borade
------------------------------

## Setup

```
# install all dependencies.
$ npm i

# run unit tests:
npm run test
```

## Run
```
# Start developing and serve your app:
npm start

```
then visit `http://localhost:9000/` to view the code in console.
