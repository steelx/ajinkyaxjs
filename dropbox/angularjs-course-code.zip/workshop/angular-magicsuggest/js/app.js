'use strict';

angular.module('app', ['app.controllers', 'app.directives']);