# Angello

[![Build Status](https://travis-ci.org/angularjs-in-action/angello.png)](https://travis-ci.org/angularjs-in-action/angello)

This is a work in progress.

Built with [Foundation](http://foundation.zurb.com/).

## Running Angello
TODO

## License
MIT
