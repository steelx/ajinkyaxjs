'use strict';

angular.module('noteriousApp', []);

