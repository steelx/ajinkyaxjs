angular-designers
=================

This is a series of simple examples to illustrate how to convert jQuery code into AngularJS.